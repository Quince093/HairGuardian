chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    sendResponse({ value: checkForIngredients(message.selectedHairType) });
});

function checkForIngredients(hairType) {
    const pageElements = document.querySelectorAll('*');
    let foundIngredientsToAvoid = {}

    if (hairType in globalThis.hairTypes) {
        globalThis.hairTypes[hairType].ingredientsToAvoid.forEach(toAvoid => {
            if (toAvoid in globalThis.ingredients) {
                toAvoidIngredient = globalThis.ingredients[toAvoid];
                toAvoidIngredient.ingredients.forEach(ingredient => {
                    pageElements.forEach(element => {
                        let formattedElementValue = element.textContent.toLowerCase().trim();
                        let formattedIngredient = ingredient.toLowerCase().trim();

                        if (formattedElementValue.indexOf(formattedIngredient) !== -1) {
                            if (!(toAvoid in foundIngredientsToAvoid)) {
                                foundIngredientsToAvoid[toAvoid] = [];
                            }

                            if (!foundIngredientsToAvoid[toAvoid].includes(formattedIngredient)) {
                                foundIngredientsToAvoid[toAvoid].push(formattedIngredient);
                            }
                        }
                    })
                })
            }
        });
    }

    return {
        toAvoid: foundIngredientsToAvoid
    };
}
