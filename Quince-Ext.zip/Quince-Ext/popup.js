// Wait till the page is fully loaded.
document.addEventListener('DOMContentLoaded', () => {
    // Dynamically add the hair types to hairTypes, assigned in popup.html
    const hairTypesSelect = document.getElementById('hairTypes');

    const foundIngredientsToAvoidList = document.getElementById('foundIngredientsToAvoid');

    const toAvoidSection = document.getElementById('toAvoid');

    const nothingFoundHeader = document.getElementById('nothingFoundHeader');

    // Grabs the check button via its ID, assigned in popup.html
    const checkButton = document.getElementById('checkButton');

    if (!hairTypesSelect || !foundIngredientsToAvoidList ||
        !toAvoidSection || !checkButton || !nothingFoundHeader) {
        console.error('Important element removed.');
        return;
    } else {
        let hairTypeOption;
        // Add hair types to hairTypes select.
        Object.keys(window.hairTypes).forEach(hairType => {
            hairTypeOption = document.createElement('option');
            hairTypeOption.text = hairType;
            hairTypeOption.value = hairType;
            hairTypesSelect.appendChild(hairTypeOption);
        })
    }

    // Hide headings.
    toAvoidSection.style.display = 'none';
    nothingFoundHeader.style.display = 'none';

    // Handle a click event
    checkButton.addEventListener('click', () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            // Send action to events.js to check for hair ingredients
            chrome.tabs.sendMessage(tabs[0].id, { selectedHairType: hairTypesSelect.value }, response => {
                foundIngredientsToAvoidList.querySelectorAll('li').forEach(element => {
                    element.remove();
                })

                if (response && response.value) {
                    if (response.value.toAvoid && Object.keys(response.value.toAvoid).length > 0) {
                        // Ensure heading is visible
                        toAvoidSection.style.display = 'block';

                        // Make sure nothing header isn't visible
                        nothingFoundHeader.style.display = 'none';

                        let foundGroupToAvoidLi;
                        let foundIngredientToAvoidList;
                        let foundIngredientToAvoidLi;
                        Object.entries(response.value.toAvoid).forEach(([group, ingredients]) => {
                            foundGroupToAvoidLi = document.createElement('li');
                            foundGroupToAvoidLi.innerHTML = `<h2>${group}</h2><p>${window.ingredients[group].reason}</p>`;

                            foundIngredientToAvoidList = document.createElement('ul');
                            foundIngredientToAvoidList.innerHTML = `<h3>Found ${group}:</h3>`;
                            ingredients.forEach(ingredient => {
                                foundIngredientToAvoidLi = document.createElement('li');
                                foundIngredientToAvoidLi.textContent = ingredient;

                                foundIngredientToAvoidList.appendChild(foundIngredientToAvoidLi);

                                foundGroupToAvoidLi.appendChild(foundIngredientToAvoidList);
                            })

                            foundIngredientsToAvoidList.appendChild(foundGroupToAvoidLi);
                        })
                    } else {
                        // Ensure heading is not visible from pass checked.
                        toAvoidSection.style.display = 'none';
                        nothingFoundHeader.style.display = 'block';
                    }
                }
            });
        });
    });
});
